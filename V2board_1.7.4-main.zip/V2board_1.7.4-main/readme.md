

# **V2Board version 1.7.4 việt hóa**

- PHP7.4+
- Composer
- MySQL5.7+
- Redis
- Laravel

## Tài liệu
[Hướng dẫn sử dụng](https://v2board.com)

## nhà tài trợ
Nhờ giấy phép dự án mã nguồn mở được cung cấp bởi [Jetbrains](https://www.jetbrains.com/)

## Cộng đồng
🔔 Kênh Telegram: [@v2board](https://t.me/v2board)  

## Phản hồi
Phiên bản được dịch bởi: [Đậu Đậu](https://zalo.me/0983538806)  
